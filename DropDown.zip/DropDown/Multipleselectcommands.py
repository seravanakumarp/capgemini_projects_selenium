import time

from selenium import webdriver
from selenium.webdriver.support.ui import Select

driver = webdriver.Chrome()
driver.get("https://demoqa.com/select-menu")

multi_select = Select(driver.find_element("id", "cars"))

if multi_select.is_multiple:
    multi_select.select_by_index(0)
    multi_select.select_by_index(1)
    time.sleep(5)
driver.quit()
