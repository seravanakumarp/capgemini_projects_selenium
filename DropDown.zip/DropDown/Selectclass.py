import time

from selenium import webdriver
from selenium.webdriver.support.ui import Select

driver = webdriver.Chrome()
driver.get("https://www.selenium.dev/selenium/web/web-form.html")

dropdown = Select(driver.find_element("name", "my-select"))
dropdown.select_by_visible_text("Two")
time.sleep(5)
driver.quit()
