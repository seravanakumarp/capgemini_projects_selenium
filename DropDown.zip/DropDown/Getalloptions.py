import time

from selenium import webdriver
from selenium.webdriver.support.ui import Select
import time
driver = webdriver.Chrome()
driver.get("https://www.selenium.dev/selenium/web/web-form.html")
time.sleep(5)
dropdown = Select(driver.find_element("name", "my-select"))

for option in dropdown.options:
    print(option.text)

driver.quit()
