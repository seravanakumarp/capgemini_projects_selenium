from selenium import webdriver
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()
driver.get("https://demoqa.com/select-menu")

# Click to open the dropdown
driver.find_element(By.ID, "react-select-2-input").send_keys("Group 1, option 2\n")

time.sleep(5)
driver.quit()
