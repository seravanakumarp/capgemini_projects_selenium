from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

driver = webdriver.Chrome()
driver.get("https://demoqa.com/dynamic-properties")

wait = WebDriverWait(driver, 10)

# Wait for the button to become clickable (simulating dynamic behavior)
button = wait.until(EC.element_to_be_clickable((By.ID, "enableAfter")))
print("Button is now clickable:", button.text)

driver.quit()
