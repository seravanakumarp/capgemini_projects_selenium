import time

from selenium import webdriver
from selenium.webdriver.support.ui import Select

driver = webdriver.Chrome()
driver.get("https://www.selenium.dev/selenium/web/web-form.html")

dropdown = Select(driver.find_element("name", "my-select"))

dropdown.select_by_visible_text("Two")
dropdown.select_by_index(1)
dropdown.select_by_value("2")
time.sleep(5)
driver.quit()
