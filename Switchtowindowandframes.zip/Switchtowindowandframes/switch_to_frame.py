from selenium import webdriver
from selenium.webdriver.common.by import By
import time

class SwitchToFrame:

    def test(self):
        baseUrl = "https://www.letskodeit.com/practice"
        driver = webdriver.Chrome()
        driver.maximize_window()
        driver.get(baseUrl)
        driver.execute_script("window.scrollBy(0, 1000);")
        time.sleep(3)
        # Switch to the iframe by ID or name
        driver.switch_to.frame("courses-iframe")

        # Interact with elements inside the iframe
        searchBox = driver.find_element(By.NAME, "course")
        searchBox.send_keys("python")

        time.sleep(3)

        # Switch back to the main content
        driver.switch_to.default_content()

        # Optional: interact with elements outside the iframe
        driver.find_element(By.ID, "name").send_keys("Test Complete")

        time.sleep(3)
        driver.quit()

ff = SwitchToFrame()
ff.test()
