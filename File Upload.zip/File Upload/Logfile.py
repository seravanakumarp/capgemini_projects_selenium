import logging

# Configure logging
logging.basicConfig(
    filename='app.log',  # Log file name
    filemode='w',         # Overwrite the log file each time ('a' for append)
    level=logging.DEBUG,  # Minimum level to capture
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# Create a logger
logger = logging.getLogger()

# Log messages of different severity
logger.debug("This is a DEBUG message - useful for diagnosing problems.")
logger.info("This is an INFO message - general information.")
logger.warning("This is a WARNING message - something unexpected happened.")
logger.error("This is an ERROR message - a serious problem occurred.")
logger.critical("This is a CRITICAL message - a very serious error.")

print("Logging complete. Check 'app.log' for output.")
