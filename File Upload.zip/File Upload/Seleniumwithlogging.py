import logging
from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# Configure logging
logging.basicConfig(
    filename='test_log.log',
    filemode='w',
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger()

try:
    logger.info("Starting the browser")
    driver = webdriver.Chrome()
    driver.maximize_window()

    logger.info("Navigating to the test page")
    driver.get("https://www.w3schools.com/html/html_forms.asp")

    logger.info("Locating the input field")
    input_field = driver.find_element(By.ID, "fname")
    input_field.clear()
    input_field.send_keys("Kumar")

    logger.info("Input entered successfully")

    time.sleep(2)

    logger.info("Closing the browser")
    driver.quit()

except Exception as e:
    logger.error("An error occurred: %s", e)
