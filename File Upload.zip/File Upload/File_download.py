from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import os
import time

# Set up download directory
download_dir = os.path.abspath("downloads")
# Creates an absolute path to a folder named downloads in your current working directory.
# Configure Chrome options

chrome_options = Options()
chrome_options.add_experimental_option("prefs", {
    "download.default_directory": download_dir,
    "download.prompt_for_download": False,
    "download.directory_upgrade": True,
    "safebrowsing.enabled": True
})
# "download.default_directory": Specifies the folder where files will be saved.
# "download.prompt_for_download": Disables the download confirmation dialog.
# "download.directory_upgrade": Allows Chrome to overwrite the default download directory.
# "safebrowsing.enabled": Enables safe browsing to avoid malicious downloads.

# Start Chrome with options
driver = webdriver.Chrome(options=chrome_options)

# Go to a page with a direct download link
driver.get("https://people.sc.fsu.edu/~jburkardt/data/csv/hw_200.csv")

# Wait for download to complete
time.sleep(5)

driver.quit()
