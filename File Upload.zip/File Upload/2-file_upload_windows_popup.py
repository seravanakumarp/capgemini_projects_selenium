from selenium import webdriver
from selenium.webdriver.common.by import By
from pynput.keyboard import Key, Controller
import time

driver = webdriver.Chrome()
driver.implicitly_wait(10)
driver.get("https://www.plupload.com/examples/")
driver.find_element(By.ID, "uploader_browse").click()
time.sleep(3)

# Controller() is part of pynput.keyboard.
# It allows you to simulate key presses on your system, not just inside a browser.

keyboard = Controller()

keyboard.type(r"C:\Users\sekumarp\Pictures\Screenshots\1.png")

keyboard.press(Key.enter)
keyboard.release(Key.enter)
time.sleep(5)

# Controller() is a class from pynput.keyboard
# that allows you to simulate keyboard actions like typing, pressing,
# and releasing keys.
# keyboard becomes an instance of Controller,
# which you can then use to send keystrokes
# to the system or an active application.