import pyautogui
import time
from selenium import webdriver
from selenium.webdriver.common.by import By

# pyautogui is a Python library used for automating GUI interactions.
# It allows your Python scripts to control the mouse and keyboard,
# take screenshots, and locate elements on the screen

# Launch browser and open a page with an input field
driver = webdriver.Chrome()
driver.get("https://www.google.com")
driver.maximize_window()

# Wait for the page to load
time.sleep(2)

# Click on the search box using Selenium to focus it
search_box = driver.find_element(By.NAME, "q")
search_box.click()

# Wait for focus
time.sleep(1)

# Use pyautogui to type text
pyautogui.write("pyautogui keyboard events", interval=0.5)

# Press ENTER
pyautogui.press("enter")

# Wait to observe result
time.sleep(10)

# Use keyboard shortcuts
pyautogui.hotkey("ctrl", "a")  # Select all
pyautogui.press("backspace")   # Delete

time.sleep(2)
driver.quit()
