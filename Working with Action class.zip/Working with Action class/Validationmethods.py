from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# Setup WebDriver (Make sure the appropriate driver is installed, e.g., ChromeDriver)
driver = webdriver.Chrome()

# Open a sample webpage
driver.get("https://www.w3schools.com/html/html_forms.asp")
time.sleep(2)  # Wait for page to load

# Locate elements
checkbox = driver.find_element(By.ID, "vehicle1")  # Example checkbox
input_field = driver.find_element(By.ID, "fname")  # Example input field

# Validation checks
print("Checkbox is enabled:", checkbox.is_enabled())      # True/False
print("Checkbox is selected:", checkbox.is_selected())    # True/False
print("Input field is displayed:", input_field.is_displayed())  # True/False

# Close the browser
driver.quit()


# is_enabled() → Checks if the element is interactable (not disabled).
# is_selected() → Checks if the element (like a checkbox or radio button) is selected.
# is_displayed() → Checks if the element is visible on the page