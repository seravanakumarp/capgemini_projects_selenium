from selenium import webdriver
from selenium.webdriver.common.by import By
import time
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


# Setup WebDriver
driver = webdriver.Chrome()
driver.get("https://testpages.herokuapp.com/styled/alerts/alert-test.html")

# 1. Handle Simple Alert
driver.find_element(By.ID, "alertexamples").click()
alert = driver.switch_to.alert
print("Simple Alert Text:", alert.text)
time.sleep(3)
alert.accept()  # Click OK


# 2. Handle Confirmation Alert
driver.find_element(By.ID, "confirmexample").click()
alert = driver.switch_to.alert
print("Confirmation Alert Text:", alert.text)
time.sleep(3)
alert.dismiss()  # Click Cancel


# 3. Handle Prompt Alert
driver.find_element(By.ID, "promptexample").click()
WebDriverWait(driver, 10).until(EC.alert_is_present())
alert = driver.switch_to.alert
time.sleep(1)
alert.send_keys("Selenium Test")  # Enter text
print("Prompt Alert Text:", alert.text)
time.sleep(3)
alert.accept()  # Click OK


# Optional: Verify the result text on the page
result = driver.find_element(By.ID, "promptreturn").text
print("Result Text:", result)

driver.quit()
