from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# Setup WebDriver (ensure chromedriver is installed and in PATH)
driver = webdriver.Chrome()

# Open a sample webpage
driver.get("https://www.w3schools.com/html/html_forms.asp")
time.sleep(2)  # Wait for page to load

# 1. Title of the page
print("Page Title:", driver.title)

# 2. Current URL
print("Current URL:", driver.current_url)

# 3. Get attribute of an element
input_element = driver.find_element(By.ID, "fname")
placeholder = input_element.get_attribute("placeholder")
print("Input field placeholder:", placeholder)

# 4. Get text of an element
label_element = driver.find_element(By.XPATH, "//label[@for='fname']")
print("Label Text:", label_element.text)

# 5. Current window handle
print("Current Window Handle:", driver.current_window_handle)

# 6. All window handles (useful when multiple tabs/windows are open)
print("All Window Handles:", driver.window_handles)

# Close the browser
driver.quit()
