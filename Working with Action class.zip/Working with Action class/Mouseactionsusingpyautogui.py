import pyautogui
import time

# 1. Move to a specific position on the screen
pyautogui.moveTo(100, 100, duration=1)  # Move to (100, 100) in 1 second
print("Moved to (100, 100)")

# 2. Perform a click
pyautogui.click()
print("Clicked")

# 3. Pause between actions
pyautogui.moveTo(200, 200, duration=1)
pyautogui.pause = 2  # Pause for 2 seconds after each action
pyautogui.click()
print("Clicked with pause")

# 4. Click and release (drag simulation)
pyautogui.mouseDown()
time.sleep(1)
pyautogui.moveTo(300, 300, duration=1)
pyautogui.mouseUp()
print("Click and release (drag)")

# 5. Reset pause (optional)
pyautogui.pause = 0
print("Pause reset")

# Optional: Display current mouse position
print("Current mouse position:", pyautogui.position())
