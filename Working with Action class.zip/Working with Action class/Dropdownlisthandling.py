from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

class MakeMyTripAutomation:
    def __init__(self):
        chrome_options = Options()
        chrome_options.add_argument("--start-maximized")
        service = Service()
        self.driver = webdriver.Chrome(service=service, options=chrome_options)

    def listhand(self, actualtext):
        self.driver.get("https://www.makemytrip.com/")
        wait = WebDriverWait(self.driver, 10)

        # Close login popup if it appears
        try:
            wait.until(EC.element_to_be_clickable((By.XPATH, "//span[@class='commonModal__close']"))).click()
        except:
            pass

        # Click on the "From" city input
        wait.until(EC.element_to_be_clickable((By.ID, "fromCity"))).click()
        time.sleep(1)

        # Type the city name to trigger suggestions
        from_input = wait.until(EC.presence_of_element_located((By.XPATH, "//input[@placeholder='From']")))
        from_input.send_keys(actualtext)
        time.sleep(2)

        # Wait for list items to appear
        wait.until(EC.presence_of_all_elements_located((By.XPATH, "//ul[@role='listbox']//li")))

        # Get all list items
        list_items = self.driver.find_elements(By.XPATH, "//ul[@role='listbox']//li")
        print(f"Found {len(list_items)} items in dropdown.")

        for item in list_items:
            try:
                text_value = item.text.strip()
                print(f"Checking: {text_value}")
                if text_value.lower() == actualtext.strip().lower():
                    item.click()
                    print(f"✅ Selected city: {text_value}")
                    break
            except Exception as e:
                print(f"Error reading item: {e}")

        time.sleep(3)
        self.driver.quit()

# Run the automation
if __name__ == "__main__":
    bot = MakeMyTripAutomation()
    bot.listhand("Mumbai")  # Replace with desired city name
