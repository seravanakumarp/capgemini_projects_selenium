from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
import time

# Setup WebDriver
driver = webdriver.Chrome()
driver.get("https://crossbrowsertesting.github.io/drag-and-drop")  # Demo page

# Locate elements
source = driver.find_element(By.ID, "draggable")
target = driver.find_element(By.ID, "droppable")

# Create ActionChains object
actions = ActionChains(driver)

# 1. move_to_element
actions.move_to_element(source)
print("Moved to source element")

# 2. pause
actions.pause(1)  # Pause for 1 second
print("Paused for 1 second")

# 3. click and hold, move to target, release
actions.click_and_hold(source).pause(1).move_to_element(target).pause(1).release()
print("Performed drag and drop using click-hold-move-release")

# 4. perform
actions.perform()
print("Actions performed")

# 5. reset_actions
actions.reset_actions()
print("Actions reset")


time.sleep(5)
driver.quit()
