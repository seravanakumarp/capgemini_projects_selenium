from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time

# Setup WebDriver
driver = webdriver.Chrome()
driver.get("https://www.google.com")

# Locate the search box
search_box = driver.find_element(By.NAME, "q")

# 1. Type text
search_box.send_keys("Selenium keyboard events")

# 2. Press ENTER
search_box.send_keys(Keys.ENTER)

time.sleep(3)

# 3. Scroll down using PAGE_DOWN
driver.find_element(By.TAG_NAME, "body").send_keys(Keys.PAGE_DOWN)
time.sleep(5)

# 4. Scroll up using PAGE_UP
driver.find_element(By.TAG_NAME, "body").send_keys(Keys.PAGE_UP)
time.sleep(5)

# 5. Refresh using F5
driver.find_element(By.TAG_NAME, "body").send_keys(Keys.F5)
time.sleep(5)

# 6. Select all text (Ctrl+A) and delete (Backspace)
search_box = driver.find_element(By.NAME, "q")
search_box.send_keys(Keys.CONTROL + "a")
search_box.send_keys(Keys.BACKSPACE)

time.sleep(5)
driver.quit()
