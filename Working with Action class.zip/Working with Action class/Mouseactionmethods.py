from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
import time

# Setup WebDriver
driver = webdriver.Chrome()
driver.get("https://www.selenium.dev/")  # You can replace this with any test page

# Create ActionChains object
actions = ActionChains(driver)

# Example 1: Move to Element (Hover)
hover_element = driver.find_element(By.LINK_TEXT, "Downloads")
actions.move_to_element(hover_element).perform()
time.sleep(2)


# Example 2: Click
click_element = driver.find_element(By.LINK_TEXT, "Projects")
actions.click(click_element).perform()
time.sleep(2)


# Example 3: Double Click
driver.get("https://testpages.herokuapp.com/styled/events/javascript-events.html")
double_click_element = driver.find_element(By.ID, "ondoubleclick")
actions.double_click(double_click_element).perform()
time.sleep(2)


# Example 4: Right Click (Context Click)
right_click_element = driver.find_element(By.ID, "oncontextmenu")
actions.context_click(right_click_element).perform()
time.sleep(2)


# Example 5: Drag and Drop
driver.get("https://crossbrowsertesting.github.io/drag-and-drop")
source = driver.find_element(By.ID, "draggable")
target = driver.find_element(By.ID, "droppable")
actions.drag_and_drop(source, target).perform()
time.sleep(2)

# Cleanup
driver.quit()
