import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By
import time
import openpyxl

# Load Excel file
df = pd.read_excel('C:/Users/sekumarp/Documents/logins.xlsx')
search_terms = df['term'].tolist()

# Setup Selenium WebDriver
options = webdriver.ChromeOptions()
options.add_argument('--headless')  # Optional
driver = webdriver.Chrome(options=options)

# Wikipedia homepage
search_url = "https://www.wikipedia.org"

for term in search_terms:
    driver.get(search_url)
    time.sleep(2)

    try:
        # Locate search box and perform search
        search_box = driver.find_element(By.ID, "searchInput")
        search_box.clear()
        search_box.send_keys(term)
        search_box.submit()

        time.sleep(2)

        # Check if redirected to a valid article page
        if "wiki" in driver.current_url:
            print(f"Search for '{term}' successful. URL: {driver.current_url}")
        else:
            print(f"Search for '{term}' did not lead to an article.")
    except Exception as e:
        print(f"Error during search for '{term}': {e}")

driver.quit()
