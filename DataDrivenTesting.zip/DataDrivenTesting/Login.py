import xml.etree.ElementTree as ET
#The ElementTree module provides an API for parsing and creating XML data.
# It represents XML as a tree structure of elements,
# allowing for easy navigation, manipulation, and serialization of XML documents in Python.
from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# Load XML file
tree = ET.parse('logins.xml')
root = tree.getroot()

# Extract search terms
search_terms = [search.find('term').text for search in root.findall('search')]
#extracts text from specific XML elements

# Setup Selenium WebDriver
options = webdriver.ChromeOptions()
options.add_argument('--headless')  # Optional
driver = webdriver.Chrome(options=options)

# Wikipedia homepage
search_url = "https://www.wikipedia.org"

for term in search_terms:
    driver.get(search_url)
    time.sleep(2)

    try:
        # Locate search box and perform search
        search_box = driver.find_element(By.ID, "searchInput")
        search_box.clear()
        search_box.send_keys(term)
        search_box.submit()

        time.sleep(2)

        # Check if redirected to a valid article page
        if "wiki" in driver.current_url:
            print(f" Search for '{term}' successful. URL: {driver.current_url}")
        else:
            print(f" Search for '{term}' did not lead to an article.")
    except Exception as e:
        print(f" Error during search for '{term}': {e}")

driver.quit()
# to read and process XML files.