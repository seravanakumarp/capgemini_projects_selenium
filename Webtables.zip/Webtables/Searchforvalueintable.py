

from selenium import webdriver
from selenium.webdriver.common.by import By

driver = webdriver.Chrome()
driver.get("https://www.w3schools.com/html/html_tables.asp")

# Locate the table
table = driver.find_element(By.ID, "customers")
rows = table.find_elements(By.TAG_NAME, "tr")


search_value = "Germany"
for row in rows[1:]:  # Skip header
    cells = row.find_elements(By.TAG_NAME, "td")
    if search_value in cells[2].text:
        print("Found:", row.text)
        break
