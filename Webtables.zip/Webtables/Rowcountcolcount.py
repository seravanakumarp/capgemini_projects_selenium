
from selenium import webdriver
from selenium.webdriver.common.by import By

driver = webdriver.Chrome()
driver.get("https://www.w3schools.com/html/html_tables.asp")

# Locate the table
table = driver.find_element(By.ID, "customers")
rows = table.find_elements(By.TAG_NAME, "tr")

rows = table.find_elements(By.TAG_NAME, "tr")
print("Total rows:", len(rows))

# Assuming first row has headers
columns = rows[0].find_elements(By.TAG_NAME, "th")
print("Total columns:", len(columns))
