from selenium import webdriver
from selenium.webdriver.common.by import By

driver = webdriver.Chrome()
driver.get("https://www.w3schools.com/html/html_tables.asp")

# Locate the table
table = driver.find_element(By.ID, "customers")
rows = table.find_elements(By.TAG_NAME, "tr")

# Get the text of the cell at 3rd row, 2nd column
cell = rows[2].find_elements(By.TAG_NAME, "td")[1]
print("Cell data:", cell.text)
