from selenium import webdriver
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()
driver.get("https://practice.expandtesting.com/dynamic-table")
driver.maximize_window()

# Optional wait for the table to load
time.sleep(3)

# Locate the table
table = driver.find_element(By.TAG_NAME, "table")
rows = table.find_elements(By.TAG_NAME, "tr")

# Loop through rows and find the one with "Chrome"
for row in rows:
    if "Chrome" in row.text:
        print("Row with Chrome:", row.text)
        break

driver.quit()
