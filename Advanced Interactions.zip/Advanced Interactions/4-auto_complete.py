from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

driver = webdriver.Chrome()
driver.maximize_window()
driver.get("https://jqueryui.com/autocomplete/")

wait = WebDriverWait(driver, 10)

# Switch to iframe that contains the autocomplete input
iframe = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, ".demo-frame")))
driver.switch_to.frame(iframe)

# Type into the autocomplete input
input_box = wait.until(EC.element_to_be_clickable((By.ID, "tags")))
input_box.send_keys("ja")

# Wait for suggestions to appear
suggestions = wait.until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, "ul.ui-menu li")))

# Click the desired suggestion
for suggestion in suggestions:
    if "Java" in suggestion.text:
        suggestion.click()
        break

time.sleep(3)
driver.quit()
