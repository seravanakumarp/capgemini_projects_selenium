

from selenium import webdriver
from selenium.webdriver.common.by import By
import time

class JavaScriptExecution():

    def test(self):
        driver = webdriver.Chrome()
        driver.maximize_window()
        driver.execute_script("window.location = 'https://www.letskodeit.com/practice';")
        driver.implicitly_wait(3)
        time.sleep(6)

        # Use JavaScript to get the element
        element = driver.execute_script("return document.getElementById('name');")

        # Wrap the JS-returned element as a WebElement if needed
        if element:
            element.send_keys("Test")
        else:
            print("Element not found")

        time.sleep(3)
        driver.quit()

ff = JavaScriptExecution()
ff.test()

# The execute_script() method in Selenium is used to execute JavaScript code
# directly within the context of the browser. This is especially useful when:
#
# You want to interact with elements that are not easily accessible
# via standard Selenium methods.
# You need to manipulate the DOM directly.
# You want to scroll, click, or retrieve values using JavaScript.