from selenium import webdriver
from selenium.webdriver.common.by import By
import time

class Screenshots():

    def test(self):
        baseUrl = "https://practicetestautomation.com/practice-test-login/"
        driver = webdriver.Chrome()
        driver.maximize_window()
        driver.get(baseUrl)
        driver.implicitly_wait(3)


        driver.find_element(By.ID, "username").send_keys("student")
        driver.find_element(By.ID, "password").send_keys("Password123")
        driver.find_element(By.ID, "submit").click()

        destinationFileName = "C:/Users/sekumarp/Documents/PYTHON/1.jpg"

        try:
            driver.save_screenshot(destinationFileName)
            print("Screenshot saved to directory --> " + destinationFileName)
        except NotADirectoryError:
            print("Not a directory issue")

        time.sleep(2)
        driver.quit()

ff = Screenshots()
ff.test()
