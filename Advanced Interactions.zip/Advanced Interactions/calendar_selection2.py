from selenium import webdriver
from selenium.webdriver.common.by import By
import time

class JQueryDatePicker:

    def test_date_picker(self):
        driver = webdriver.Chrome()
        driver.maximize_window()
        driver.get("https://jqueryui.com/datepicker/")
        driver.implicitly_wait(5)

        # Switch to the iframe containing the date picker
        driver.switch_to.frame(driver.find_element(By.CLASS_NAME, "demo-frame"))

        # Click the input field to open the calendar
        driver.find_element(By.ID, "datepicker").click()

        # Navigate to Oct 2025
        while True:
            month_year = driver.find_element(By.CLASS_NAME, "ui-datepicker-title").text
            if "October 2025" in month_year:
                break
            driver.find_element(By.CLASS_NAME, "ui-datepicker-next").click()
            time.sleep(0.3)

        # Select the 30th
        driver.find_element(By.XPATH, "//a[text()='30']").click()

        time.sleep(3)
        driver.quit()

ff = JQueryDatePicker()
ff.test_date_picker()
