from selenium import webdriver
from selenium.webdriver.common.by import By
import time

class HYRDatePicker:

    def test_date_picker(self):
        driver = webdriver.Chrome()
        driver.maximize_window()
        driver.get("https://www.hyrtutorials.com/p/calendar-practice.html")
        driver.implicitly_wait(5)

        # Click the first date picker input
        driver.find_element(By.ID, "first_date_picker").click()

        # Navigate to October 2025
        while True:
            month_year = driver.find_element(By.CLASS_NAME, "ui-datepicker-title").text
            if "October 2025" in month_year:
                break
            driver.find_element(By.CLASS_NAME, "ui-datepicker-next").click()
            time.sleep(0.3)

        # Select the 30th
        driver.find_element(By.XPATH, "//a[text()='30']").click()

        time.sleep(3)
        driver.quit()

ff = HYRDatePicker()
ff.test_date_picker()
