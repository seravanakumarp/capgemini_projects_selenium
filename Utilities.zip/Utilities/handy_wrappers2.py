from selenium.webdriver.common.by import By

class HandyWrappers:
    def __init__(self, driver):
        self.driver = driver

    def get_Element(self, locator, locatorType="id"):
        locatorType = locatorType.lower()
        if locatorType == "id":
            return self.driver.find_element(By.ID, locator)
        elif locatorType == "name":
            return self.driver.find_element(By.NAME, locator)
        elif locatorType == "xpath":
            return self.driver.find_element(By.XPATH, locator)
        elif locatorType == "css":
            return self.driver.find_element(By.CSS_SELECTOR, locator)
        elif locatorType == "class":
            return self.driver.find_element(By.CLASS_NAME, locator)
        elif locatorType == "link":
            return self.driver.find_element(By.LINK_TEXT, locator)
        else:
            print(f"Locator type '{locatorType}' not supported.")
            return None
