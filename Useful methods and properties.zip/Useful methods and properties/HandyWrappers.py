

from selenium.webdriver.common.by import By

class HandyWrappers:

    def __init__(self, driver):
        self.driver = driver

    def get_element(self, locator, locator_type="id"):
        locator_type = locator_type.lower()
        if locator_type == "id":
            return self.driver.find_element(By.ID, locator)
        elif locator_type == "name":
            return self.driver.find_element(By.NAME, locator)
        elif locator_type == "xpath":
            return self.driver.find_element(By.XPATH, locator)
        elif locator_type == "css":
            return self.driver.find_element(By.CSS_SELECTOR, locator)
        elif locator_type == "class":
            return self.driver.find_element(By.CLASS_NAME, locator)
        elif locator_type == "link":
            return self.driver.find_element(By.LINK_TEXT, locator)
        else:
            print(f"Locator type '{locator_type}' not supported.")
            return None
