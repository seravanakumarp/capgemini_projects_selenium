from selenium import webdriver
from selenium.webdriver.common.by import By
from Utilities.handy_wrappers1 import HandyWrappers
import time


class ElementPresentCheck():

    def test(self):
        baseUrl = "https://www.letskodeit.com/practice"
        driver = webdriver.Chrome()
        driver.maximize_window()
        driver.implicitly_wait(10)

        # It helps make your test scripts cleaner, more readable, and easier to maintain.
        hw = HandyWrappers(driver)
        driver.get(baseUrl)

        elementResult1 = hw.isElementPresent("name", By.ID)
        print(str(elementResult1))

        elementResult2 = hw.elementPresenceCheck("//input[@id='name1']", By.XPATH)
        print(str(elementResult2))


ff = ElementPresentCheck()
ff.test()