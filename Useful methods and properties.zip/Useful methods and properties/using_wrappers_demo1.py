from selenium import webdriver
from Utilities.handy_wrappers2 import HandyWrappers
import time

class UsingWrappers1():

    def test(self):
        baseUrl = "https://www.letskodeit.com/practice"
        driver = webdriver.Chrome()
        driver.maximize_window()
        driver.implicitly_wait(10)
        hw = HandyWrappers(driver)
        driver.get(baseUrl)

        # Corrected: specify locator type as 'id'
        textField1 = hw.get_Element("name", locatorType="id")
        textField1.send_keys("Test")
        time.sleep(2)

        # Using XPath to locate the same field and clear it
        textField2 = hw.get_Element("//input[@id='name']", locatorType="xpath")
        textField2.clear()

ff = UsingWrappers1()
ff.test()
