from selenium import webdriver
from HandyWrappers import HandyWrappers  # assuming it's saved as handy_wrappers.py
import time
driver = webdriver.Chrome()
driver.get("https://www.letskodeit.com/practice")

hw = HandyWrappers(driver)
element = hw.get_element("name", "id")
if element:
    element.send_keys("Test input")
    time.sleep(5)
