
from selenium import webdriver
from Utilities.handy_wrappers import HandyWrappers
import time

driver = webdriver.Chrome()
driver.maximize_window()
driver.get("https://practicetestautomation.com/practice-test-login/")

hw = HandyWrappers(driver)

# Dynamic XPath for username, password, and login button
username = "student"
password = "Password123"

username_xpath = f"//input[@id='username' and @name='username']"
password_xpath = f"//input[@id='password' and @name='password']"
login_button_xpath = f"//button[contains(text(), 'Submit')]"

# Interact with elements
hw.get_element(username_xpath, "xpath").send_keys(username)
hw.get_element(password_xpath, "xpath").send_keys(password)
hw.get_element(login_button_xpath, "xpath").click()

time.sleep(5)
driver.quit()
# A HandyWrappers class is a custom helper class that wraps frequently used Selenium
# methods into reusable functions. This helps:

# Reduce code duplication
# Improve readability
# Centralize error handling
# The HandyWrappers class is designed to:
#
# Abstract and simplify the process of locating web elements.

# Allow you to specify locator types (like "id", "xpath", "css", etc.)
# without repeating find_element() logic.

# Make your Selenium scripts cleaner, more readable, and easier to maintain.

# use of HandyWrappers in Selenium is to simplify and
# standardize common WebDriver operations like checking element presence,
# interacting with elements, and handling exceptions.