import time
from selenium import webdriver
from selenium.webdriver.common.by import By

class FindByClassTag:

    def test(self):
        base_url = "https://www.letskodeit.com/practice"
        driver = webdriver.Chrome()
        driver.get(base_url)
        driver.implicitly_wait(10)

        # Find element by class name
        element_by_class_name = driver.find_element(By.CLASS_NAME, "inputs")
        if element_by_class_name:
            print("Element Found -> By Class Name")
            element_by_class_name.send_keys("Testing")

        # Find element by tag name
        element_by_tag_name = driver.find_element(By.TAG_NAME, "a")
        if element_by_tag_name:
            links = driver.find_elements(By.TAG_NAME, "a")
            for link in links:
                text = link.text.strip()
                if text:
                    print("Link Text:", text)

        time.sleep(5)
        driver.quit()

# Run the test
run_tests = FindByClassTag()
run_tests.test()
