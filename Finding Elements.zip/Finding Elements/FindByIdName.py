from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException

class FindByIdName():

    def test(self):
        baseUrl = "https://www.letskodeit.com/practice"
        driver = webdriver.Chrome()
        driver.get(baseUrl)

        try:
            elementById = driver.find_element(By.ID, "name")
            print("We found an element by Id")
        except NoSuchElementException:
            print("Element by Id not found")

        try:
            elementByName = driver.find_element(By.NAME, "show-hide")
            print("We found an element by Name")
        except NoSuchElementException:
            print("Element by Name not found")

        driver.get("https://www.yahoo.com/")
        try:
            driver.find_element(By.ID, "yui_3_18_0_4_1463100170626_1148")
        except NoSuchElementException:
            print("Element not found on Yahoo (as expected)")

        driver.quit()

ff = FindByIdName()
ff.test()
