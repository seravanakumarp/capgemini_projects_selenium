from selenium import webdriver
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.by import By
import time

class DropdownSelect:

    def test(self):
        baseUrl = "https://www.letskodeit.com/practice"
        driver = webdriver.Chrome()
        driver.maximize_window()
        driver.get(baseUrl)
        driver.implicitly_wait(10)

        # Locate the dropdown element by ID
        element = driver.find_element(By.ID, "carselect")
        sel = Select(element)

        sel.select_by_value("benz")
        print("Selected Benz by value")
        time.sleep(2)

        sel.select_by_index(2)  # Index must be an integer
        print("Selected Honda by index")
        time.sleep(2)

        sel.select_by_visible_text("BMW")
        print("Selected BMW by visible text")
        time.sleep(2)

        sel.select_by_index(2)
        print("Selected Honda again by index")

        driver.quit()

# Run the test
ff = DropdownSelect()
ff.test()
