from selenium import webdriver
from selenium.webdriver.common.by import By
import time

class RadioButtonsAndCheckboxes:

    def test(self):
        base_url = "https://www.letskodeit.com/practice"
        driver = webdriver.Chrome()
        driver.maximize_window()
        driver.get(base_url)
        driver.implicitly_wait(10)

        # Select radio buttons
        bmw_radio_btn = driver.find_element(By.ID, "bmwradio")
        bmw_radio_btn.click()
        time.sleep(2)

        benz_radio_btn = driver.find_element(By.ID, "benzradio")
        benz_radio_btn.click()
        time.sleep(2)

        # Select checkboxes
        bmw_checkbox = driver.find_element(By.ID, "bmwcheck")
        bmw_checkbox.click()
        time.sleep(2)

        benz_checkbox = driver.find_element(By.ID, "benzcheck")
        benz_checkbox.click()
        time.sleep(2)

        # Print selection status
        print("BMW Radio button is selected? " + str(bmw_radio_btn.is_selected()))
        print("Benz Radio button is selected? " + str(benz_radio_btn.is_selected()))
        print("BMW Checkbox is selected? " + str(bmw_checkbox.is_selected()))
        print("Benz Checkbox is selected? " + str(benz_checkbox.is_selected()))

        driver.quit()

# Run the test
if __name__ == "__main__":
    test_instance = RadioButtonsAndCheckboxes()
    test_instance.test()
