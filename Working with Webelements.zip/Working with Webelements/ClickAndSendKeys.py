from selenium import webdriver
from selenium.webdriver.common.by import By
import time
from selenium.common.exceptions import StaleElementReferenceException

class ClickAndSendKeys():

    def test(self):
        baseUrl = "https://letskodeit.teachable.com"
        driver = webdriver.Chrome()
        driver.maximize_window()
        driver.get(baseUrl)
        driver.implicitly_wait(10)

        # Click login link
        loginLink1 = driver.find_element(By.XPATH, "//div[@id='navbar']//a[@href='/sign_in']")
        loginLink1.click()

        # First email field interaction
        emailField1 = driver.find_element(By.ID, "email")
        emailField1.send_keys("test")

        # Click login with password link
        loginLink2 = driver.find_element(By.ID, "login-with-password-link")
        loginLink2.click()

        # Second email field interaction
        emailField2 = driver.find_element(By.NAME, "email")
        emailField2.send_keys("test@gmail.com")

        # Password field interaction
        passwordField = driver.find_element(By.ID, "password")
        passwordField.send_keys("test")

        time.sleep(3)

        # Re-locate and interact with emailField1 again
        try:
            emailField1 = driver.find_element(By.ID, "email")
            emailField1.clear()
            emailField1.send_keys("test")
        except StaleElementReferenceException:
            emailField1 = driver.find_element(By.ID, "email")
            emailField1.clear()
            emailField1.send_keys("test")

        time.sleep(3)


        driver.quit()

ff = ClickAndSendKeys()
ff.test()
