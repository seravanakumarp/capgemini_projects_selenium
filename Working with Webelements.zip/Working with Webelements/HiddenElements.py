from selenium import webdriver
from selenium.webdriver.common.by import By
import time

class HiddenElements:

    def testLetsKodeIt(self):
        baseUrl = "https://www.letskodeit.com/practice"
        driver = webdriver.Chrome()
        driver.maximize_window()
        driver.get(baseUrl)
        driver.implicitly_wait(2)

        # Find the state of the text box
        textBoxElement = driver.find_element(By.ID, "displayed-text")
        textBoxState = textBoxElement.is_displayed()
        print("Text is visible? " + str(textBoxState))
        time.sleep(2)

        # Click the Hide button
        driver.find_element(By.ID, "hide-textbox").click()
        textBoxState = textBoxElement.is_displayed()
        print("Text is visible after hiding? " + str(textBoxState))
        time.sleep(2)

        # Scroll up and click the Show button
        driver.execute_script("window.scrollBy(0, -150);")
        driver.find_element(By.ID, "show-textbox").click()
        textBoxState = textBoxElement.is_displayed()
        print("Text is visible after showing? " + str(textBoxState))
        time.sleep(2)


        driver.quit()

    def testExpedia(self):
        print("⚠️ Expedia test skipped: Site structure has changed and may not work with static IDs.")
        # If you still want to test Expedia, we can update this using current selectors.

# Run the tests
ff = HiddenElements()
ff.testLetsKodeIt()
# ff.testExpedia()  # Uncomment if you want to update this with new selectors
