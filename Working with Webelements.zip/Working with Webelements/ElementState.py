import time

from selenium import webdriver
from selenium.webdriver.common.by import By

class ElementState:

    def isEnabled(self):
        baseUrl = "http://www.google.com"
        driver = webdriver.Chrome()
        driver.maximize_window()
        driver.get(baseUrl)
        driver.implicitly_wait(3)

        # Use the 'name' attribute to locate the search box
        search_box = driver.find_element(By.NAME, "q")

        # Check if the search box is enabled
        is_enabled = search_box.is_enabled()
        print("Search box is enabled? ->", is_enabled)

        # Type something if enabled
        if is_enabled:
            search_box.send_keys("letskodeit")
        time.sleep(5)
        driver.quit()

# Run the test
e = ElementState()
e.isEnabled()
